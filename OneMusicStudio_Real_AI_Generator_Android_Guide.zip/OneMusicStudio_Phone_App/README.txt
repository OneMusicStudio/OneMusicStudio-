ONEMUSIC STUDIO — REAL AI MUSIC GENERATOR CONNECTOR
==================================================

This is an installable, mobile-first music-generation app with a real backend adapter. It does not synthesize fake songs or simulate successful generation. It submits requests to an ACE-Step 1.5 API server, checks the job state, and serves the resulting audio for playback/download.

IMPORTANT LIMITATION
--------------------
This ZIP is the app and connector, not the large AI model or a hosted GPU. Real song generation starts only after ACE-Step is deployed somewhere reachable and ACESTEP_BASE_URL is configured. I cannot truthfully say generation is live until the app's connection check succeeds and a test song returns playable audio.

FEATURES
--------
- Mobile-first installable web app for Android Chrome
- Prompt and editable lyrics fields
- Genre, mood, vocal-style, instrumental, and song-duration controls
- Real generation job submission and status polling
- Audio playback and download when the AI API returns audio
- On-device saved-song library, edit/retry workflow, exportable library backup
- Backend health indicator and clear errors when the model is not configured
- API key stays on the backend; it is not sent to the browser
- Current ACE-Step REST API and legacy endpoint compatibility

DEPLOY THE APP BACKEND
----------------------
1. Upload the contents of this folder to a Git repository or deploy the folder to a Python/Docker hosting service.
2. Use the included Dockerfile, or install requirements.txt and run:
   uvicorn server:app --host 0.0.0.0 --port ${PORT:-8080}
3. Configure these environment variables in the app host:
   ACESTEP_BASE_URL = base URL of the separately running ACE-Step API (no trailing slash)
   ACESTEP_API_KEY = optional server-side API key if your model API requires one
   ACESTEP_MODEL = acestep-v15-turbo (optional; default is this model)
4. Redeploy/restart the app after setting environment variables.
5. Open the app's HTTPS URL on your Android phone. Tap “Check connection.” It must report the AI server is reachable before generating.
6. In Chrome, open ⋮ and choose “Install app” or “Add to Home screen.”

DEPLOY THE AI ENGINE SEPARATELY
-------------------------------
ACE-Step needs a machine/cloud service with the required model files and compatible compute. The official install guide documents running the UI/API and hardware requirements. Start with:
https://github.com/ACE-Step/ACE-Step-1.5
https://github.com/ACE-Step/ACE-Step-1.5/blob/main/docs/en/API.md
https://github.com/ACE-Step/ACE-Step-1.5/blob/main/docs/en/INFERENCE.md

The model API's base URL is the host root that responds to /health and the documented API routes. Do not use a web UI page URL unless that deployment also exposes the REST API. Free web-hosting tiers generally do not provide the GPU and storage needed for sustained music generation; a cloud GPU may cost money. This project does not include model weights or promise free compute.

SUPPORTED API ROUTES
--------------------
Current API:
- POST /v1/music/generate
- GET /v1/jobs/{job_id}
- GET /v1/audio?path=...
- GET /health

Legacy API fallback:
- POST /release_task
- POST /query_result
- GET /v1/audio?path=...

The backend supports the current and legacy API shapes, but third-party forks may differ. If the health check works but a generation request fails, check the server logs and the API version exposed by your model host.

SECURITY
--------
- Do not put API keys into index.html or other browser-side files.
- Use HTTPS for public deployments.
- Restrict access to your AI API where possible; do not expose an unauthenticated GPU endpoint to the public internet.
- Saved song metadata is stored in the browser on the current device. Export the library backup before clearing browser data.

LOCAL APP CHECK
---------------
Install Python 3.11+ and dependencies:
  pip install -r requirements.txt
Run:
  uvicorn server:app --host 0.0.0.0 --port 8080
Open http://localhost:8080. Without ACESTEP_BASE_URL, the app correctly reports that the AI engine is not configured and refuses to fake a generation.
