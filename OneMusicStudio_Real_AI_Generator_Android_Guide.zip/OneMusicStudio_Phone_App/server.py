"""OneMusic Studio backend: real ACE-Step 1.5 API adapter.

Supports current ACE-Step API (/v1/music/generate + /v1/jobs/{job_id}) and
legacy ACE-Step API (/release_task + /query_result). No fake audio is generated.
"""
import os
from pathlib import Path
from urllib.parse import quote
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).resolve().parent
UPSTREAM = os.getenv("ACESTEP_BASE_URL", "").strip().rstrip("/")
API_KEY = os.getenv("ACESTEP_API_KEY", "").strip()
MODEL = os.getenv("ACESTEP_MODEL", "acestep-v15-turbo").strip() or "acestep-v15-turbo"
app = FastAPI(title="OneMusic Studio API", version="1.1.0")


def headers(json_content=True):
    h = {"Accept": "application/json"}
    if json_content:
        h["Content-Type"] = "application/json"
    if API_KEY:
        h["Authorization"] = f"Bearer {API_KEY}"
    return h


def require_upstream():
    if not UPSTREAM:
        raise HTTPException(503, "The AI music engine is not configured yet. Deploy an ACE-Step 1.5 API server, then set ACESTEP_BASE_URL in the backend environment variables.")


def unwrap(data):
    if isinstance(data, dict) and isinstance(data.get("data"), (dict, list)):
        return data["data"]
    return data


@app.get("/api/health")
async def health():
    configured = bool(UPSTREAM)
    model_ok = False
    detail = "AI server URL is not configured"
    api_version = "unknown"
    if configured:
        try:
            async with httpx.AsyncClient(timeout=12, follow_redirects=True) as client:
                r = await client.get(f"{UPSTREAM}/health", headers=headers(False))
                if r.is_success:
                    model_ok = True
                    try:
                        d = unwrap(r.json())
                        if isinstance(d, dict):
                            api_version = str(d.get("version", d.get("service", "available")))
                    except Exception:
                        api_version = "available"
                    detail = "Connected to ACE-Step API"
                else:
                    detail = f"AI server health check returned HTTP {r.status_code}"
        except Exception as e:
            detail = f"AI server unreachable ({type(e).__name__})"
    return {"app": "OneMusic Studio", "configured": configured, "ai_server_ok": model_ok,
            "model": MODEL, "api_version": api_version, "message": detail}


@app.post("/api/generate")
async def generate(req: Request):
    require_upstream()
    try:
        body = await req.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON request")
    prompt = str(body.get("prompt", "")).strip()[:5000]
    lyrics = str(body.get("lyrics", "")).strip()[:12000]
    if not prompt and not lyrics:
        raise HTTPException(400, "Enter a song description or lyrics.")
    genre = str(body.get("genre", "Pop"))[:80]
    mood = str(body.get("mood", "Emotional"))[:80]
    vocal = str(body.get("vocal", "Male vocal"))[:80]
    instrumental = bool(body.get("instrumental", False)) or vocal.lower() == "instrumental"
    title = str(body.get("title", "Untitled song"))[:120]
    caption = ", ".join(x for x in [genre, mood, vocal if not instrumental else "instrumental", prompt] if x)
    duration = 60
    try:
        duration = max(10, min(300, int(body.get("duration", 60))))
    except (TypeError, ValueError):
        pass

    # Current ACE-Step 1.5 REST API payload. "caption" is the current documented field.
    modern_payload = {
        "caption": caption,
        "lyrics": "" if instrumental else lyrics,
        "instrumental": instrumental,
        "thinking": True,
        "audio_format": "mp3",
        "batch_size": 1,
        "model": MODEL,
        "duration": duration,
    }
    # Older official/forked deployments use release_task + query_result and accept prompt/audio_duration.
    legacy_payload = {
        "prompt": caption,
        "lyrics": "" if instrumental else lyrics,
        "instrumental": instrumental,
        "thinking": True,
        "audio_format": "mp3",
        "batch_size": 1,
        "model": MODEL,
        "audio_duration": duration,
    }
    try:
        async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
            r = await client.post(f"{UPSTREAM}/v1/music/generate", json=modern_payload, headers=headers())
            endpoint = "modern"
            if r.status_code in (404, 405, 501):
                r = await client.post(f"{UPSTREAM}/release_task", json=legacy_payload, headers=headers())
                endpoint = "legacy"
            data = r.json() if r.content else {}
            if not r.is_success:
                inner = unwrap(data)
                msg = (inner.get("error") or inner.get("message")) if isinstance(inner, dict) else None
                raise HTTPException(502, str(msg or f"ACE-Step API returned HTTP {r.status_code}"))
            inner = unwrap(data)
            if not isinstance(inner, dict):
                raise HTTPException(502, "ACE-Step returned an unexpected response. Check the configured API URL.")
            task_id = inner.get("job_id") or inner.get("task_id") or inner.get("taskId") or inner.get("id")
            state = str(inner.get("status", "")).lower()
            if state in ("succeeded", "success", "completed", "complete", "done"):
                return {"status": "succeeded", "task_id": task_id, "title": title,
                        "result": inner.get("result", inner), "audio_urls": extract_audio_urls(inner), "api": endpoint}
            if state in ("failed", "error"):
                raise HTTPException(502, str(inner.get("error") or inner.get("message") or "ACE-Step generation failed."))
            if not task_id:
                # Some versions return the generated output directly rather than a job ID.
                urls = extract_audio_urls(inner)
                if urls:
                    return {"status": "succeeded", "task_id": None, "title": title, "result": inner, "audio_urls": urls, "api": endpoint}
                raise HTTPException(502, "ACE-Step accepted no identifiable job and returned no audio link. Confirm that ACESTEP_BASE_URL points to the API server, not its web UI.")
            return {"status": "queued", "task_id": str(task_id), "title": title,
                    "message": "Generation job submitted to ACE-Step.", "api": endpoint}
    except HTTPException:
        raise
    except httpx.TimeoutException:
        raise HTTPException(504, "The AI server took too long to accept the job. Try again.")
    except Exception as e:
        raise HTTPException(502, f"Could not submit generation job ({type(e).__name__}).")


@app.get("/api/status/{task_id}")
async def status(task_id: str):
    require_upstream()
    task_id = task_id.strip()
    if not task_id or len(task_id) > 200 or any(c in task_id for c in "\\/?#"):
        raise HTTPException(400, "Invalid generation job ID")
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        # Current ACE-Step API: GET /v1/jobs/{job_id}
        try:
            r = await client.get(f"{UPSTREAM}/v1/jobs/{quote(task_id, safe='')}", headers=headers(False))
            if r.status_code not in (404, 405, 501):
                if r.is_success:
                    data = unwrap(r.json())
                    if isinstance(data, dict):
                        return normalize_status(data, task_id)
                elif r.status_code not in (400, 422):
                    raise HTTPException(502, f"ACE-Step job status returned HTTP {r.status_code}")
        except HTTPException:
            raise
        except Exception:
            pass
        # Legacy API: POST /query_result with several known request shapes.
        last_error = "unknown response"
        for payload in ({"task_id_list": [task_id]}, {"task_ids": [task_id]}, {"task_id": task_id}):
            try:
                r = await client.post(f"{UPSTREAM}/query_result", json=payload, headers=headers())
                if not r.is_success:
                    last_error = f"HTTP {r.status_code}"
                    continue
                data = unwrap(r.json())
                items = data if isinstance(data, list) else data.get("results", data.get("task_results", data.get("data", [data]))) if isinstance(data, dict) else [data]
                if isinstance(items, dict): items = [items]
                item = items[0] if items else (data if isinstance(data, dict) else {})
                if not isinstance(item, dict): item = {"result": item}
                return normalize_status(item, task_id)
            except Exception as e:
                last_error = type(e).__name__
    raise HTTPException(502, f"Could not read generation status ({last_error}). Check the ACE-Step API version and URL.")


def normalize_status(item, task_id):
    raw = item.get("status", item.get("task_status", item.get("state", "processing")))
    state = str(raw).lower()
    if state in ("1", "success", "succeeded", "completed", "complete", "done"):
        return {"status": "succeeded", "task_id": task_id, "result": item.get("result", item), "audio_urls": extract_audio_urls(item)}
    if state in ("2", "failed", "error"):
        return {"status": "failed", "task_id": task_id, "error": item.get("error") or item.get("message") or "Music generation failed on the AI server."}
    return {"status": "processing", "task_id": task_id,
            "message": item.get("message") or item.get("status_message") or item.get("detail") or "The AI model is creating your song…"}


def extract_audio_urls(obj):
    found = []
    audio_exts = (".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac")
    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                key = k.lower()
                if isinstance(v, str) and (key in ("url", "audio_url", "audio_path", "path", "file", "filepath", "file_path", "download_url") or v.lower().split("?")[0].endswith(audio_exts)):
                    if v.startswith(("http://", "https://")):
                        found.append(v)
                    elif v.startswith("/v1/audio?"):
                        found.append("/api/audio?path=" + quote(v, safe=""))
                    elif v.startswith("/") or "/" in v or v.lower().split("?")[0].endswith(audio_exts):
                        found.append("/api/audio?path=" + quote(v, safe=""))
                else:
                    walk(v)
        elif isinstance(x, list):
            for v in x: walk(v)
    walk(obj)
    return list(dict.fromkeys(found))[:8]


@app.get("/api/audio")
async def audio(path: str):
    require_upstream()
    clean = path.strip()
    if clean.startswith(("http://", "https://")) or ".." in clean or "\x00" in clean:
        raise HTTPException(400, "Invalid audio path")
    if clean.startswith("/v1/audio?"):
        upstream_path = clean
    else:
        upstream_path = "/v1/audio?path=" + quote(clean, safe="")
    try:
        async with httpx.AsyncClient(timeout=120, follow_redirects=True) as client:
            r = await client.get(f"{UPSTREAM}{upstream_path}", headers=headers(False))
        if not r.is_success:
            raise HTTPException(502, f"Audio download failed (HTTP {r.status_code}).")
        media = r.headers.get("content-type", "audio/mpeg")
        suffix = ".wav" if "wav" in media else ".flac" if "flac" in media else ".mp3"
        return StreamingResponse(iter([r.content]), media_type=media,
                                 headers={"Content-Disposition": f"inline; filename=onemusic-generated{suffix}", "Cache-Control": "private, max-age=3600"})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"Audio could not be retrieved ({type(e).__name__}).")


@app.get("/")
async def home(): return FileResponse(ROOT / "index.html")
@app.get("/manifest.webmanifest")
async def manifest(): return FileResponse(ROOT / "manifest.webmanifest", media_type="application/manifest+json")
@app.get("/sw.js")
async def service_worker(): return FileResponse(ROOT / "sw.js", media_type="application/javascript")
@app.get("/icon.svg")
async def icon(): return FileResponse(ROOT / "icon.svg", media_type="image/svg+xml")
app.mount("/static", StaticFiles(directory=str(ROOT)), name="static")
